var playState = {
	create:function(){
		this.keyboard = game.input.keyboard;
		this.player = game.add.sprite(16,16,'player');
		game.physics.enable(this.player,phaser.physics.ARCADE);

		this.win = game.add.sprite(256,256,'win');
		game.physics.enable(this.win,phaser.physics.ARCADE);


	},

	update:function(){
		game.physics.arcade.overlap(this.player,this.win,this.Win,null,this);

		if(this.keyboard.isDown(Phaser.Keyboard.A)){
			this.player.body.velocity.x = -150;
		} else if (this.keyboard.isDown(Phaser.Keyboard.D)){
			this.player.body.velocity.x = -150;
		} else {
			this.player.body.velocity.x = 0;
		}

		if(this.keyboard.isDown(Phaser.Keyboard.W)){
			this.player.body.velocity.y = 150;
		} else if (this.keyboard.isDown(Phaser.Keyboard.X)){
			this.player.body.velocity.y = -150;
		} else {
			this.player.body.velocity.y = 0;
		}


	},

	win:function(){
		game.state.start('win');
	}


};